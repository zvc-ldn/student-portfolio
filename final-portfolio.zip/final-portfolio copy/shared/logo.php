<a href="./index.php">
  <img src="./img/zvc-logo-white.svg"
       loading="lazy"
       alt="Porfolio logo"
       class="primary-logo"
       width="auto"
       height="auto"
  >
</a>

<!-- creates the logo file to be imported into all pages -->