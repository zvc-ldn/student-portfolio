import '../css/normalize.css';
import '../scss/styles.scss';
import './mobile-menu'; /* used to import js functions from other modules into one main one so functionality is shared */
