<nav class="social-menu">
  <ul class="social-menu-list">
    <!-- <li class="social-menu-item">
      <a href="https://www.facebook.com/basementstudionotts/" target="_blank" class="social-menu-link">
        <img src="./img/facebook-brands-white.svg" class="social-menu-image" alt="Facebook logo" width="auto"
             height="auto">
      </a>
    </li> -->

    <li class="social-menu-item">
      <a href="https://www.instagram.com/zvc.dzn/" target="_blank" class="social-menu-link">
        <img src="./img/instagram-brands-white.svg" class="social-menu-image" alt="Instagram logo" width="auto"
             height="auto">
      </a>
    </li>

    <li class="social-menu-item">
      <a href="https://www.github.com/zvc-ldn" target="_blank" class="social-menu-link">
        <img src="./img/github_PNG58.png" class="social-menu-image" alt="Spotify logo" width="auto"
             height="auto">
      </a>
    </li>

    <li class="social-menu-item">
      <a href="mailto:17071012@stu.mmu.ac.uk" target="_blank" class="social-menu-link">
        <img src="./img/Outlook.com_icon.png" class="social-menu-image" alt="Soundcloud logo" width="auto"
             height="auto">
      </a>
    </li> 
  </ul>
</nav>

<!-- creates the social media icons file shown on the side panel to be imported into all pages -->