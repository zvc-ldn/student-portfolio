<div class="side-panel">
  <?php include './shared/social-menu.php' ?>
</div>
<!-- creates the side panel to be imported into all pages -->