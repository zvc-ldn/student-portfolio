<nav id="js-primary-navigation" class="primary-navigation">
  <ul class="menu">
    <li class="menu-item">
      <a href="./index.php" class="menu-link">
        Home
      </a>
    </li>

    <li class="menu-item">
      <a href="./portfolio.php" class="menu-link">
        Portfolio
      </a>
    </li>

    <li class="menu-item">
      <a href="./cv.php" class="menu-link">
        CV
      </a>
    </li>

    <li class="menu-item">
      <a href="./blog.php" class="menu-link">
        Blog
      </a>
    </li>

    <li class="menu-item">
      <a href="./contact.php" class="menu-link">
        Contact
      </a>
    </li>
  </ul>
</nav>

<!-- creates the seperate navigatio file to be imported into all pages -->
