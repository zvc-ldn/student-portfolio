<footer id="js-primary-footer" class="primary-footer">
  <div class="container">
    <p>
      &copy; MMU Student Portfolio 2020 - Zachari Pierre-Powell
    </p>
  </div>
</footer>

<script src="./dist/main.js"></script>
